/* -----------------------------
   Module xmldata.h
      2008-05-06: created by jcr
   -----------------------------
*/
#ifndef _XMLDATA
#define _XMLDATA

/* ---- Data Types ---- */
#define TEXTNODE 1001
#define ELEMNODE 1002

/* -- Dummy Declarations -- */
struct sTextNode;
typedef struct sTextNode *TextNodePtr, TextNode;
struct sElemNode;
typedef struct sElemNode *ElemNodePtr, ElemNode;
/* ------------------------ */

/* ---- Attributes ---- */

typedef struct sAttrList
  {
    char *name;
    char *value;
    struct sAttrList *next;
  } Attr, *AttrList;

AttrList consAttrList( char *n, char *v, AttrList l );
void showAttrList( AttrList l );
AttrList add2AttrList( AttrList l1, AttrList l2);
 
/* ---- Element Nodes ---- */
typedef union
  {
    TextNodePtr t;
    ElemNodePtr e;  
  } uNode;

typedef struct sNode
  {
    int type;
    uNode val;
  } Node, *NodePtr;
NodePtr consNodefromText( TextNodePtr n );
NodePtr consNodefromElem( ElemNodePtr n );
void    showNodeESIS( NodePtr node );
NodePtr add2NodeList( NodePtr nl, NodePtr node );

struct sTextNode
  {
    char * contents;
    NodePtr sibling;
  };
TextNodePtr consTextNode( char *c, NodePtr s );

struct sElemNode
  {
    char *name;
    AttrList attrs;
    NodePtr sibling;
    NodePtr child;
  };
ElemNodePtr consElemNode( char * name, AttrList attrlist, NodePtr s, NodePtr c );

typedef struct sProcInstNode
  {
    char *procid;
    AttrList attrs;
  } ProcInstNode, *ProcInstNodePtr;

typedef struct sDAT  /* -- Document Abstract Tree -- */
  {
    ProcInstNodePtr declaration;
    ElemNodePtr     root;
    NodePtr         child;
  } DAT, *DATPtr;
DATPtr consDAT( ProcInstNodePtr decl, ElemNodePtr root, NodePtr child );

#endif
