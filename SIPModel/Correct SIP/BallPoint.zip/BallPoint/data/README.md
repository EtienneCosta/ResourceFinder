# LuxuryInk

```sh
Ballpoint sales webpage
```

## Display

![alt text](https://github.com/EtienneCosta/Mestrado/blob/main/PRI2020/TP1/index.png)



![alt text](https://github.com/EtienneCosta/Mestrado/blob/main/PRI2020/TP1/sales.png)


